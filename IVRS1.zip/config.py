# config.py
MODEL_PATH = r"./model/best.pt"
PLATE_PATTERN = r'^[A-Z]{2}[0-9]{1,2}[A-Z]{1,2}[0-9]{4}$'
CONFIDENCE_THRESHOLD = 0.4
PASSWORD="995544"
