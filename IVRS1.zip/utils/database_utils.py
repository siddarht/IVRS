# database_utils.py

import pyodbc
from config import PASSWORD

DB_CONNECTION_STRING = (
    "DRIVER={ODBC Driver 17 for SQL Server};"
    "SERVER=DESKTOP-6BACJ5K\\SQLEXPRESS;"
    "DATABASE=IVRS;"
    "UID=sa;"
    f"PWD={PASSWORD}"
)

def check_plate_in_database(plate_number):
    conn = pyodbc.connect(DB_CONNECTION_STRING)
    cursor = conn.cursor()
    query = "SELECT PassNo FROM RegisteredVehicles WHERE VehicleNo = ?"
    cursor.execute(query, (plate_number,))
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    if result:
        return True, result[0]
    return False, None

def add_visitor_entry(vehicle_no, visit_date, visit_time):
    conn = pyodbc.connect(DB_CONNECTION_STRING)
    cursor = conn.cursor()
    query = "INSERT INTO Visitor (VehicleNo, VisitDate, VisitTime) VALUES (?, ?, ?)"
    cursor.execute(query, (vehicle_no, visit_date, visit_time))
    conn.commit()
    cursor.close()
    conn.close()

def add_registered_vehicle(name, personalno, passno, vehicleno):
    conn = pyodbc.connect(DB_CONNECTION_STRING)
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM registeredvehicles WHERE vehicleno = ?", (vehicleno,))
    if cursor.fetchone():
        cursor.close()
        conn.close()
        return False  
    query = "INSERT INTO registeredvehicles (name, personalno, passno, vehicleno) VALUES (?, ?, ?, ?)"
    cursor.execute(query, (name, personalno, passno, vehicleno))
    conn.commit()
    cursor.close()
    conn.close()
    return True 

def delete_registered_vehicle(vehicle_no):
    conn = pyodbc.connect(DB_CONNECTION_STRING)
    cursor = conn.cursor()
    query = "DELETE FROM RegisteredVehicles WHERE VehicleNo = ?"
    cursor.execute(query, (vehicle_no,))
    conn.commit()
    cursor.close()
    conn.close()

def get_all_registered_vehicles():
    conn = pyodbc.connect(DB_CONNECTION_STRING)
    cursor = conn.cursor()
    query = "SELECT Name, PersonalNo, PassNo, VehicleNo FROM RegisteredVehicles"
    cursor.execute(query)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return rows

def get_all_visitor_logs():
    conn = pyodbc.connect(DB_CONNECTION_STRING)
    cursor = conn.cursor()
    query = "SELECT VehicleNo, VisitDate, VisitTime FROM Visitor ORDER BY VisitDate DESC, VisitTime DESC"
    cursor.execute(query)
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    visitor_logs = [
        (f"{row.VisitDate} {row.VisitTime}", row.VehicleNo)
        for row in rows
    ]
    return visitor_logs
